package com.WebApp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="CourseRegistrations")
public class CourseRegistration {
	
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;

	
    public Long getId() {
		return id;
	}
    

	public void setId(Long id) {
		this.id = id;
	}
	

	@ManyToOne()
    @JoinColumn(name = "studentid")
    private StudentRegistration student;
    
	
	@ManyToOne()
    @JoinColumn(name = "courseid")
    private Courses course;
    
	
    private double pgrade;
    
    
    private double fgrade;
    
    
    private double Avgrade;
    
    
    public double getAvgrade() {
		return Avgrade;
	}

	public void setAvgrade(double avgrade) {
		Avgrade = avgrade;
	}

	public StudentRegistration getStudent() {
		return student;
	}

	public void setStudent(StudentRegistration student) {
		this.student = student;
	}

	public Courses getCourse() {
		return course;
	}

	public void setCourse(Courses course) {
		this.course = course;
	}

	public double getPgrade() {
		return pgrade;
	}

	public void setPgrade(double pgrade) {
		this.pgrade = pgrade;
	}

	public double getFgrade() {
		return fgrade;
	}

	public void setFgrade(double fgrade) {
		this.fgrade = fgrade;
	}



    
}
