package com.WebApp.statistics;

import com.WebApp.model.Courses;


public interface StatisticsStrategy {
	
	double calculateStatistic(Courses course);
	
	String getName();
}
