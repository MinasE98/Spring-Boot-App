package com.WebApp.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.WebApp.Service.CourseRegistrationService;
import com.WebApp.Service.CoursesService;
import com.WebApp.Service.StudentRegistrationService;
import com.WebApp.model.CourseRegistration;
import com.WebApp.model.Courses;
import com.WebApp.model.StudentRegistration;
import com.WebApp.statistics.MaxStrategy;
import com.WebApp.statistics.MeanStatisticStrategy;
import com.WebApp.statistics.MedianStrategy;
import com.WebApp.statistics.MinStrategy;
import com.WebApp.statistics.SkewnesStatisticStrategy;
import com.WebApp.statistics.StandarDeviationStrategy;
import com.WebApp.statistics.StatisticsStrategy;

@Controller
public class CoursesMgtAppController {
	//COURSES
	@Autowired
	private CoursesService courseService;
	
	
	@Autowired
	private CourseRegistrationService registrationService;
	
	
	@Autowired
	private StudentRegistrationService studentService;
	
	
	private Map<String,Double>MeanList= new HashMap<String,Double>();
	
	
	@RequestMapping("/courses/showform")
	public String showFormForCourses(Model Model) {
		Courses course = new Courses();
		
		Model.addAttribute("course", course);
		
		return "Courses/courseForm";
	}
	
	
	@RequestMapping("/courses/showformUpdate")
	public String showFormForUpdate(@ModelAttribute("courseid") int id, Model Model) {
		Courses course = courseService.find(id);
		
		Model.addAttribute("course", course);
		
		return "Courses/courseForm";
	}

	
	@RequestMapping("/courses/list")
	public String showCourses(Model Model) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
		  username = ((UserDetails)principal).getUsername();
		} else {
		  username = principal.toString();
		}
		List<Courses> Courses =courseService.findCourseByInstructor(username) ;
		Model.addAttribute("courses", Courses);
		return "Courses/CoursesList";
		
	}
	
	
	@RequestMapping("/courses/save")
	public  String saveCourses(@ModelAttribute("course") Courses course, Model Model) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		String username;
		if (principal instanceof UserDetails) {
		  username = ((UserDetails)principal).getUsername();
		} else {
		  username = principal.toString();
		}
		course.setInstructor(username);
    	courseService.save(course);
		return "redirect:/courses/list";
		
	}
	
	
	@RequestMapping("/courses/update")
	public  String updateCourses(Courses course) {
		
		courseService.update(course);
		return "redirect:/courses/list";
		
	}
	
	
	@RequestMapping("/courses/delete")
	public  String deleteCourses(@ModelAttribute("course") Courses course, Model Model) {
		List<CourseRegistration>reglist=registrationService.findRegistrationByCourseid(course.getCourseid());
		for (CourseRegistration cR : reglist)registrationService.delete(cR);
		courseService.delete(course.getCourseid());
		return "redirect:/courses/list";
		
	}
	
	
	@RequestMapping("/courses/show_students")
	public  String show_students_list(@ModelAttribute("courseid") int id, Model Model) {
		Courses course=courseService.find(id);
		Model.addAttribute("course",course);
		List<CourseRegistration> theStudents =registrationService.findRegistrationByCourseid(id);
		Model.addAttribute("students", theStudents);
		
		return "Courses/Course_studentList";
		
	}

	
	@RequestMapping("/courses/add_student")
	public  String add_student(@ModelAttribute("courseid") int id, Model Model) {
		Courses course=courseService.find(id);
		Model.addAttribute("course",course);
		List<StudentRegistration> theStudents =studentService.findAll();
		Model.addAttribute("students", theStudents);
		
		
		return "Courses/addform";
		
	}
	
	
	@RequestMapping("/courses/add_student_in_course")
	public  String add_student_in_course(@ModelAttribute("courseid") int courseid,@ModelAttribute("studentid") int sid, Model Model) {
		CourseRegistration registration=new CourseRegistration();
		Courses course =courseService.find(courseid);
		StudentRegistration	student = studentService.find(sid);
		courseService.update(course);
		if (registrationService.findCourseRegistrations(courseid, sid) == null) {
			registration.setCourse(course);
			registration.setStudent(student);
			course.getRegistrations().add(registration);
			registrationService.save(registration);
		}
		return "redirect:/courses/add_student?courseid="+courseid;
		
	}
	
	
	@RequestMapping("/courses/rem_student")
	public  String rem_student(@ModelAttribute("courseid") int courseid,@ModelAttribute("studentid") int sid, Model Model) {
		Courses n =courseService.find(courseid);
		CourseRegistration registration=registrationService.findCourseRegistrations(courseid, sid);
		registrationService.delete(registration);
		courseService.save(n);
		return "redirect:/courses/show_students?courseid="+courseid;
		
	}
	
	
	@RequestMapping("/courses/add_student_grade")
	public String add_student_grade(@ModelAttribute("courseid") int courseid,@ModelAttribute("studentid") int sid, Model Model) {
		Courses course =courseService.find(courseid);
		StudentRegistration student=studentService.find(sid);
		CourseRegistration registration = registrationService.findCourseRegistrations(courseid, sid);
		Model.addAttribute("course",course);
		Model.addAttribute("student", student);
		Model.addAttribute("registration",registration);
		return "Courses/gradesForm"; 

	}	
	
	
	@RequestMapping("/courses/save_grade")
	public String save_grade(@ModelAttribute("registration") CourseRegistration registration,@ModelAttribute("courseid") int courseid,@ModelAttribute("studentid") int sid, Model Model) {
		Model.addAttribute("registration",registration);
		registration.setAvgrade(registration.getFgrade()*0.5 + registration.getPgrade()*0.5);
		registrationService.save(registration);
		return "redirect:/courses/show_grades?courseid="+courseid; 

	}	
	
	
	@RequestMapping("/courses/show_grades")
	public String show_grades(@ModelAttribute("courseid") int id, Model Model) {
		Courses course=courseService.find(id);
		Model.addAttribute("course",course);
		List<CourseRegistration>  registrations =registrationService.findRegistrationByCourseid(id);
		Model.addAttribute("registrations", registrations);
		return "Courses/gradesList";
		
	}
	
	
	@RequestMapping("/courses/search")
	public String search(@ModelAttribute("courseid") int id,@ModelAttribute("studentid") int sid, Model Model) {
		Optional<StudentRegistration> studentf=studentService.findbyId(sid);
		if(studentf.isPresent()) {
			StudentRegistration student = studentService.find(sid);
			Courses course =courseService.find(id);
			CourseRegistration registration = registrationService.findCourseRegistrations(id, sid);
			Model.addAttribute("course",course);
			Model.addAttribute("student", student);
			Model.addAttribute("registration",registration);
			return "Courses/gradesForm"; 
		}
		return "redirect:/courses/show_grades?courseid="+id;
		
		
	}
	
	
	@RequestMapping("/courses/calculate_grades")
	public String  calculate_grades(@ModelAttribute("courseid") int courseid,Model Model) {
		List<StatisticsStrategy> StatisticsStrategy = new ArrayList<StatisticsStrategy>();
		MeanStatisticStrategy mean = new MeanStatisticStrategy();
		SkewnesStatisticStrategy Skewnes=new SkewnesStatisticStrategy();
		MaxStrategy max=new MaxStrategy();
		MinStrategy min=new MinStrategy();
		MedianStrategy median = new MedianStrategy();
		StandarDeviationStrategy deviation=new StandarDeviationStrategy();
		StatisticsStrategy.add(mean);
		StatisticsStrategy.add(Skewnes);
		StatisticsStrategy.add(max);
		StatisticsStrategy.add(min);
		StatisticsStrategy.add(median);
		StatisticsStrategy.add(deviation);
		courseService.setStatisticsStrategy(StatisticsStrategy);
		Map<String,Double> Statistics= courseService.getCourseStatistics(courseService.find(courseid));
		MeanList.put(courseService.find(courseid).getName(), Statistics.get("Max"));
		List<Integer> graph_data=new ArrayList<Integer>();
		int fail=0;
		int pass=0;
		for (CourseRegistration cR : registrationService.findRegistrationByCourseid(courseid)) {
			if(cR.getAvgrade()>=0 && cR.getAvgrade()<50)fail++;
			if(cR.getAvgrade()>=50 && cR.getAvgrade()<=100)pass++;	
		}
		graph_data.add(fail);
		graph_data.add(pass);
		Model.addAttribute("Course",courseService.find(courseid));
		Model.addAttribute("Data",graph_data);
		Model.addAttribute("Statistics",Statistics);
		return "Courses/graphs";
	
	}	
	
	
	//STUDENTS
	@RequestMapping("/students/showform")
	public String showFormForAdd(Model theModel) {
		
		StudentRegistration student = new StudentRegistration();
		
		theModel.addAttribute("student", student);
		
		return "Students/studentreg";
	}
	
	
	@RequestMapping("/students/list")
	public String showStudents(Model theModel) {
		List<StudentRegistration> theStudents = studentService.findAll();
		theModel.addAttribute("students", theStudents);
		return "Students/studentList";
		
	}
	
	
	@RequestMapping("/students/save")
	public  String saveStudents(@ModelAttribute("student") StudentRegistration student, Model theModel) {
			studentService.save(student);
		return "redirect:/students/list";
		
	}
	
	
	@RequestMapping("/students/delete")
	public String deleteStudents(@RequestParam("studentId") Integer id) {
		List<CourseRegistration>reglist=registrationService.findRegistrationByStudentid(id);
		for (CourseRegistration cR : reglist)registrationService.delete(cR);
		studentService.delete(id);
		return "redirect:/students/list";
		
	}
	
	
	@RequestMapping("/students/showformUpdate")
	public String showFormForUpdateStudent(@ModelAttribute("studentid") int id,Model theModel) {
		
		StudentRegistration student = studentService.find(id);
		
		theModel.addAttribute("student", student);
		
		return "Students/studentreg";
	}
	
}
