package com.WebApp.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.WebApp.DAO.CourseRegistrationDAO;
import com.WebApp.model.CourseRegistration;
@Service
public class CourseRegistrationServiceImpl implements CourseRegistrationService {
	@Autowired
	private CourseRegistrationDAO registrationRepository;
	
	@Override
	public void save(CourseRegistration registration) {
		registrationRepository.save(registration);
		
	}

	@Override
	public CourseRegistration findCourseRegistrations(Integer id,Integer sid) {
		return registrationRepository.findCourseRegistrations(id,sid);
	}

	@Override
	public void update(CourseRegistration registration) {
		registrationRepository.save(registration);
		
	}

	@Override
	public void delete(CourseRegistration registration) {
		registrationRepository.delete(registration);
	}

	@Override
	public List<CourseRegistration> findRegistrationByCourseid(Integer id) {
		return registrationRepository.findRegistrationByCourseid(id);
	}

	@Override
	public List<CourseRegistration> findRegistrationByStudentid(Integer id) {
		return registrationRepository.findRegistrationByStudentid(id);
		
	}

}
