package com.WebApp.Service;

import java.util.List;
import java.util.Optional;
import com.WebApp.model.StudentRegistration;

public interface StudentRegistrationService {
	
	void save(StudentRegistration student);
	
	void update(StudentRegistration student);
	
	void delete(Integer id);
	
	StudentRegistration find(Integer id);
	
	Optional<StudentRegistration> findbyId(Integer id);
	
	List<StudentRegistration> findAll();
}
