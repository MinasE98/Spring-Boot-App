package com.WebApp.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.WebApp.model.CourseRegistration;

public interface CourseRegistrationDAO extends JpaRepository<CourseRegistration, Integer> {

	@Query("SELECT courseregistration from CourseRegistration courseregistration where course.courseid = ?1 and student.id=?2")
	CourseRegistration findCourseRegistrations(Integer cid,Integer sid);
	
	
	@Query("SELECT courseregistration from CourseRegistration courseregistration where course.courseid = ?1")	
	List<CourseRegistration> findRegistrationByCourseid(Integer cid);
	
	
	@Query("SELECT courseregistration from CourseRegistration courseregistration where student.id = ?1")	
	List<CourseRegistration> findRegistrationByStudentid(Integer cid);
}
