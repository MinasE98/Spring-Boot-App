package com.WebApp.statistics;

public class MaxStrategy extends TemplateStatisticsStrategy {
	
	@Override
	public void doActualCalculation() {
		result=descriptiveStatistics.getMax();
	}
	
	
	public void getNameofClass() {
		name="Max";
	}
}
