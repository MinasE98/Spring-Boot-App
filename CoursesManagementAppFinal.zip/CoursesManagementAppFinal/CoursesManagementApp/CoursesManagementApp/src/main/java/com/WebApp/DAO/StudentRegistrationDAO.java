package com.WebApp.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import com.WebApp.model.StudentRegistration;



public interface StudentRegistrationDAO extends JpaRepository<StudentRegistration,Integer> {


}