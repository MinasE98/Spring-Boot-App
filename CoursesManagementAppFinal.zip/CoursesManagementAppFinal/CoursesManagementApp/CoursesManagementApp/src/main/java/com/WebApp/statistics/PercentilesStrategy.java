package com.WebApp.statistics;

public class PercentilesStrategy extends TemplateStatisticsStrategy{

	@Override
	public void doActualCalculation() {
		//result = descriptiveStatistics.getPercentile(result);
	}

	
	@Override
	public void getNameofClass() {
		name="Percentiles";
		
	}

}
