package com.WebApp.statistics;

public class StandarDeviationStrategy extends TemplateStatisticsStrategy {

	@Override
	public void doActualCalculation() {
		result=descriptiveStatistics.getStandardDeviation();
	}

	
	@Override
	public void getNameofClass() {
		name="Standar Deviation";
		
	}

}
