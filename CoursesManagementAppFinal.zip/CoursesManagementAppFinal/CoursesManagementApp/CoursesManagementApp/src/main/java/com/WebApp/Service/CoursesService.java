package com.WebApp.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.WebApp.model.Courses;
import com.WebApp.statistics.StatisticsStrategy;

public interface CoursesService {
	List<Courses> findCourseByInstructor(String instructor);
	
	void save(Courses course);
	
	Courses find(Integer id);
	
	Optional<Courses> findbyId(Integer id);
	
	void update(Courses course);
	
	void delete(Integer id);
	
	List<StatisticsStrategy> getStatisticsStrategy();
	
	void setStatisticsStrategy(List<StatisticsStrategy> statisticsStrategy);
	
	Map<String,Double> getCourseStatistics(Courses course);
}
