package com.WebApp.statistics;

public class KurtosisStrategy extends TemplateStatisticsStrategy {

	@Override
	public void doActualCalculation() {
		result=descriptiveStatistics.getKurtosis();
	}

	
	@Override
	public void getNameofClass() {
		name="Kurtosis";
		
	}
}
