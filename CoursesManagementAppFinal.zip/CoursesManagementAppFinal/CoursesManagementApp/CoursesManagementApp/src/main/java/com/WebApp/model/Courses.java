package com.WebApp.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity 
@Table(name="Courses")
public class Courses {
	  @Id
	  private int courseid;
	  
	  @Column(name="Name")
	  private String name;
	  
	  @Column(name="Instructor")
	  private String instructor;
	  
	  @Column(name="Description")
	  private String Description;
	  
	  @OneToMany()
	  @JoinColumn(name = "Registrations")
	  private Set<CourseRegistration> Registrations = new HashSet<CourseRegistration>();

	  
	  public String getDescription() {
		 return Description;
	  }

	
	  public Set<CourseRegistration> getRegistrations() {
			return Registrations;
	  }
		
	
	  public void setRegistrations(Set<CourseRegistration> registrations) {
			Registrations = registrations;
	  }
		  
	
	  public void setDescription(String description) {
			Description = description;
	  }
		

	
	  public int getCourseid() {
	    return courseid;
	  }
	
	  public void setCourseid(int courseid) {
	    this.courseid = courseid;
	  }
	
	  public String getName() {
	    return name;
	  }
	
	  public void setName(String name) {
	    this.name = name;
	  }
	
	  public String getInstructor() {
		return instructor;
	  }
	
	  public void setInstructor(String instructor) {
		this.instructor = instructor;
	  }
}