package com.WebApp.statistics;

public class MedianStrategy extends TemplateStatisticsStrategy {

	@Override
	public void doActualCalculation() {
		int check=(int) descriptiveStatistics.getN();
		if(check% 2==0) {
			 double sum=descriptiveStatistics.getElement(check/2)+descriptiveStatistics.getElement(check/2-1);
			 result=sum/2;
		}else {
			result=descriptiveStatistics.getElement(Math.round(check/2));
		}	
	}

	
	@Override
	public void getNameofClass() {
		name="Median";
	}
}
