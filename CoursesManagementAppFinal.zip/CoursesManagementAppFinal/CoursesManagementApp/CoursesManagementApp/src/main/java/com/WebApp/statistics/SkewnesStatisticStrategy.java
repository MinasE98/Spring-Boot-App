package com.WebApp.statistics;

public class SkewnesStatisticStrategy extends TemplateStatisticsStrategy {

	@Override
	public void doActualCalculation() {
		result=descriptiveStatistics.getSkewness();
	}

	@Override
	public void getNameofClass() {
		name="Skewnes";
		
	}
}
