package com.WebApp.statistics;

public class VarianceStrategy extends TemplateStatisticsStrategy {

	@Override
	public void doActualCalculation() {
		result=descriptiveStatistics.getVariance();
	}

	@Override
	public void getNameofClass() {
		name="Variance";
	}

}
