package com.WebApp.statistics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.springframework.stereotype.Component;
import com.WebApp.model.CourseRegistration;
import com.WebApp.model.Courses;
@Component
public abstract class TemplateStatisticsStrategy implements StatisticsStrategy {
	DescriptiveStatistics descriptiveStatistics = new DescriptiveStatistics();
	
	protected double result;
	
	protected String name;
	
	@Override
	public double calculateStatistic(Courses course) {
		prepareDataSet(course);
		doActualCalculation();
		return result;
	}
	
	
	public String getName() {
		getNameofClass();
		return name;
	}
	
	
	private void prepareDataSet(Courses course) {
		List<Double> grades=new ArrayList<Double>();
		for(CourseRegistration sR : course.getRegistrations()) {
			grades.add(sR.getAvgrade());
		}
		Collections.sort(grades);
		for(int i=0;i<grades.size();i++)descriptiveStatistics.addValue(grades.get(i));
	}
	
	
	public abstract void getNameofClass();
	
	public  abstract void doActualCalculation();
}