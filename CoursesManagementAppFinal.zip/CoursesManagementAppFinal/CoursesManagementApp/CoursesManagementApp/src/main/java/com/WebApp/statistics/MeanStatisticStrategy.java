package com.WebApp.statistics;

public class MeanStatisticStrategy extends TemplateStatisticsStrategy{

	@Override
	public void doActualCalculation() {
		result = descriptiveStatistics.getMean();
	}

	
	@Override
	public void getNameofClass() {
		name="Mean";	
	}
}
