package com.WebApp.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.WebApp.model.Courses;


public interface CoursesDAO extends JpaRepository<Courses,Integer>{

	public List<Courses> findCourseByInstructor(String instructor);
	
}
