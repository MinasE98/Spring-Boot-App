package com.WebApp.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.WebApp.DAO.StudentRegistrationDAO;
import com.WebApp.model.StudentRegistration;

@Service
public class StudentRegistrationServiceImpl implements StudentRegistrationService {
	@Autowired
	private StudentRegistrationDAO studentRepository;

	@Override
	public void save(StudentRegistration student) {
		studentRepository.save(student);

	}

	@Override
	public void update(StudentRegistration student) {
		studentRepository.save(student);

	}

	@Override
	public void delete(Integer id) {
		studentRepository.deleteById(id);

	}

	public StudentRegistration find(Integer id) {
		return studentRepository.getById(id);
	}
	
	public Optional<StudentRegistration> findbyId(Integer id) {
		return studentRepository.findById(id);
	}
	
	@Override
	public List<StudentRegistration> findAll() {
		return studentRepository.findAll();
	}

}
