package com.WebApp.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.WebApp.DAO.CoursesDAO;
import com.WebApp.model.Courses;
import com.WebApp.statistics.StatisticsStrategy;
@Service

public class CoursesServiceImpl implements CoursesService {
	@Autowired
	private CoursesDAO coursesRepository;
	
	
	private List<StatisticsStrategy> StatisticsStrategy;

	
	public List<StatisticsStrategy> getStatisticsStrategy() {
		return StatisticsStrategy;
	}

	
	public void setStatisticsStrategy(List<StatisticsStrategy> statisticsStrategy) {
		StatisticsStrategy = statisticsStrategy;
	}

	
	public  List<Courses> findCourseByInstructor( String instructor) {
		return coursesRepository.findCourseByInstructor(instructor);
	}

	
	@Override
	public void save(Courses course) {
		coursesRepository.save(course);	
	}
	
	
	public Courses find(Integer id) {
		return coursesRepository.getById(id);	
	}
	
	
	@Override
	public void update(Courses course) {
		coursesRepository.save(course);	
	}

	
	@Override
	public void delete(Integer id) {
		coursesRepository.deleteById(id);
		
	}
	
	
	public Optional<Courses> findbyId(Integer id) {
		return coursesRepository.findById(id);
	}
	
	
	public Map<String,Double> getCourseStatistics(Courses course){
		Map<String,Double> returns = new HashMap<>();
		for (StatisticsStrategy St : StatisticsStrategy)returns.put(St.getName(),St.calculateStatistic(course) );
		return returns;
	}
	

}
