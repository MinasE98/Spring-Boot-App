package com.WebApp.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="StudentRegistration")
public class StudentRegistration {

	@Id
	private int id;
	@Column(name="YearOfRegistration")
	private int yor;
	
	@Column(name="Semester")
	private int semester;
	
	@Column(name="Name",nullable=false)
	private String Name;


	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public int getYor() {
		return yor;
	}
	
	public void setYor(int yor) {
		this.yor = yor;
	}
	
	public int getSemester() {
		return semester;
	}
	
	public void setSemester(int semester) {
		this.semester = semester;
	}
	
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		Name = name;
	}

	
}
