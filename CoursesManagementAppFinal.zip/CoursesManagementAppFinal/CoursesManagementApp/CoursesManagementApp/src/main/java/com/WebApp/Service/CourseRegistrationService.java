package com.WebApp.Service;

import java.util.List;

import com.WebApp.model.CourseRegistration;

public interface CourseRegistrationService {
	void save(CourseRegistration registration);
	
	CourseRegistration findCourseRegistrations (Integer cid,Integer sid);
	
	void update(CourseRegistration registration);
	
	void delete(CourseRegistration registration);
	
	List<CourseRegistration> findRegistrationByCourseid(Integer id);
	
	List<CourseRegistration> findRegistrationByStudentid(Integer id);
	
}
