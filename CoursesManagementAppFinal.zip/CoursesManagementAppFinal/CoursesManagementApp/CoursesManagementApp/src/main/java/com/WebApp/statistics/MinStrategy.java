package com.WebApp.statistics;

public class MinStrategy extends TemplateStatisticsStrategy {

	@Override
	public void doActualCalculation() {
		result=descriptiveStatistics.getMin();
	}

	
	@Override
	public void getNameofClass() {
		name="Min";
	}

}
