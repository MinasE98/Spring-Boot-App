package com.WebApp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import com.WebApp.Service.CourseRegistrationService;
import com.WebApp.Service.CoursesService;
import com.WebApp.Service.StudentRegistrationService;
import com.WebApp.model.CourseRegistration;
import com.WebApp.model.Courses;
import com.WebApp.model.StudentRegistration;
import com.WebApp.statistics.MaxStrategy;
import com.WebApp.statistics.MeanStatisticStrategy;
import com.WebApp.statistics.MedianStrategy;
import com.WebApp.statistics.MinStrategy;
import com.WebApp.statistics.SkewnesStatisticStrategy;
import com.WebApp.statistics.StandarDeviationStrategy;
import com.WebApp.statistics.StatisticsStrategy;

@SpringBootTest
@TestPropertySource( locations = "classpath:application-dev.properties")
@TestInstance(Lifecycle.PER_CLASS)
class TestWebAppService {
	
	@Autowired
	CoursesService courseService;
	
	@Autowired
	CourseRegistrationService registrationService;
	
	@Autowired
	StudentRegistrationService studentService;
	
	@BeforeAll
	@Transactional
    public void setup() {
		StudentRegistration tS= new StudentRegistration();
		tS.setId(5555);
		tS.setName("Kostis Pirkotis");
		tS.setSemester(7);
		tS.setYor(2018);
		studentService.save(tS);
		StudentRegistration tS2= new StudentRegistration();
		tS2.setId(5556);
		tS2.setName("Nikos Test");
		tS2.setSemester(7);
		tS2.setYor(2018);
		studentService.save(tS2);
		StudentRegistration tS3= new StudentRegistration();
		tS3.setId(5557);
		tS3.setName("Markos Test");
		tS3.setSemester(7);
		tS3.setYor(2018);
		studentService.save(tS3);
		Courses tC = new Courses();
		tC.setCourseid(998);
		tC.setInstructor("gmarios");
		tC.setName("Testing1");
		tC.setDescription(null);
		courseService.save(tC);
		Courses tC2 = new Courses();
		tC2.setCourseid(997);
		tC2.setInstructor("gmarios");
		tC2.setName("Testing2");
		tC2.setDescription(null);
		courseService.save(tC2);
		CourseRegistration R1 =new CourseRegistration();
		R1.setCourse(tC);
		R1.setStudent(tS);
		R1.setPgrade(65);
		R1.setFgrade(55);
		R1.setAvgrade(60);
		registrationService.save(R1);
		CourseRegistration R2 =new CourseRegistration();
		R2.setCourse(tC);
		R2.setStudent(tS2);
		R2.setPgrade(65);
		R2.setFgrade(65);
		R2.setAvgrade(65);
		registrationService.save(R2);
		CourseRegistration R3 =new CourseRegistration();
		R3.setCourse(tC);
		R3.setStudent(tS3);
		R3.setPgrade(45);
		R3.setFgrade(45);
		R3.setAvgrade(45);
		registrationService.save(R3);
		tC.getRegistrations().add(R1);
		tC.getRegistrations().add(R2);
		tC.getRegistrations().add(R3);
		courseService.update(tC);
		
    }
	
	
	@Test
	void testCoursesServiceIsNotNull() {
		Assertions.assertNotNull(courseService);
	}
	
	
	@Test
	void testCourseRegistrationServiceIsNotNull() {
		Assertions.assertNotNull(registrationService);
	}
	
	
	@Test
	void testStudentRegistrationServiceIsNotNull() {
		Assertions.assertNotNull(studentService);
	}
	
	
	//Courses
	
	@Test
	void testfindCourseByInstructor() {
		List<Courses> storedCourses = courseService.findCourseByInstructor("gmarios");
		Assertions.assertNotNull(storedCourses);
		for (Courses sR : storedCourses)Assertions.assertEquals("gmarios", sR.getInstructor());
		
	}
	
	
	@Test
	@Transactional
	void testSaveCourse() {
		Courses tC3 = new Courses();
		tC3.setCourseid(999);
		tC3.setInstructor("gmarios");
		tC3.setName("Testing1");
		tC3.setDescription(null);
		courseService.save(tC3);
		Assertions.assertEquals(999,courseService.find(999).getCourseid());
		
	}
	
	
	@Test
	@Transactional
	void testUpdateCourse() {
		Assertions.assertNull(courseService.find(998).getDescription());
		Courses testCourse=courseService.find(998);
		testCourse.setDescription(" C++ lectures");
		courseService.update(testCourse);
		Assertions.assertEquals(" C++ lectures",courseService.find(998).getDescription());
		
	}

	
	@Test
	@Order(1)
	@Transactional
	void testDeleteCourse() {
		Courses tC= new Courses();
		tC.setCourseid(999);
		tC.setInstructor("gmarios");
		tC.setName("Testing3");
		courseService.save(tC);
		Assertions.assertTrue(courseService.findbyId(999).isPresent());
		courseService.delete(999);
		Assertions.assertTrue(courseService.findbyId(999).isEmpty());
		
	}
	
	
	@Test
	@Transactional
	void testGetCourseStatistics() {
		List<StatisticsStrategy> StatisticsStrategy = new ArrayList<StatisticsStrategy>();
		MeanStatisticStrategy mean = new MeanStatisticStrategy();
		SkewnesStatisticStrategy Skewnes=new SkewnesStatisticStrategy();
		MaxStrategy max=new MaxStrategy();
		MinStrategy min=new MinStrategy();
		MedianStrategy median = new MedianStrategy();
		StandarDeviationStrategy deviation=new StandarDeviationStrategy();
		StatisticsStrategy.add(mean);
		StatisticsStrategy.add(Skewnes);
		StatisticsStrategy.add(max);
		StatisticsStrategy.add(min);
		StatisticsStrategy.add(median);
		StatisticsStrategy.add(deviation);
		courseService.setStatisticsStrategy(StatisticsStrategy);
		Map<String,Double> Statistics= courseService.getCourseStatistics(courseService.find(998));
		Assertions.assertEquals(-1.2933427807333937,Statistics.get(Skewnes.getName()));
		Assertions.assertEquals(56.666666666666664,Statistics.get(mean.getName()));
		Assertions.assertEquals(65.0,Statistics.get(max.getName()));
		Assertions.assertEquals(45.0,Statistics.get(min.getName()));
		Assertions.assertEquals(60.0,Statistics.get(median.getName()));	
		Assertions.assertEquals(10.408329997330663,Statistics.get(deviation.getName()));
	}
	
	
	
	//Students
	
	
	@Test
	@Transactional
	void testfindAll() {
		List<StudentRegistration> storedStudents = studentService.findAll();
		Assertions.assertNotNull(storedStudents);
		
	}
	
	
	@Test
	@Transactional
	void testfindStudent() {
		StudentRegistration test=studentService.find(5555);
		Assertions.assertEquals(5555,test.getId());
		
	}
	
	
	@Test
	@Transactional
	void testSaveStudent() {
		StudentRegistration tS= new StudentRegistration();
		tS.setId(5569);
		tS.setName("Nikos Test");
		tS.setSemester(7);
		tS.setYor(2018);
		studentService.save(tS);
		StudentRegistration stored=studentService.find(5569);
		Assertions.assertEquals(5569,stored.getId());
		
	}

	
	@Test
	@Order(3)
	@Transactional
	void testUpdateStudent() {
		StudentRegistration test= studentService.find(5555);
		test.setName("Kostas Pirkotis");
		studentService.update(test);
		Assertions.assertEquals("Kostas Pirkotis",test.getName());
		
	}
	
	
	@Test
	@Order(2)
	@Transactional
	void testDeleteStudent() {
		StudentRegistration tS= new StudentRegistration();
		tS.setId(5569);
		tS.setName("Nikos Test");
		tS.setSemester(7);
		tS.setYor(2018);
		studentService.save(tS);
		Assertions.assertTrue(studentService.findbyId(5569).isPresent());
		studentService.delete(5569);
		Assertions.assertTrue(studentService.findbyId(5569).isEmpty());
		
	}
	
	
	//Registrations
	
	
	@Test
	@Transactional
	void testfindRegistrationByCourseidShouldReturnAList() {
		List<CourseRegistration> listcR= registrationService.findRegistrationByCourseid(998);
		Assertions.assertNotNull(listcR);
		for (CourseRegistration cR : listcR)Assertions.assertEquals(998, cR.getCourse().getCourseid());
	}

	
	@Test
	@Transactional
	void testfindRegistrationByStudentidShouldReturnAList() {
		List<CourseRegistration> listcR= registrationService.findRegistrationByStudentid(5555);
		Assertions.assertNotNull(listcR);
		for (CourseRegistration cR : listcR)Assertions.assertEquals(5555, cR.getStudent().getId());
	}
	
	
	@Test
	@Transactional
	void testfindCourseRegistrations() {
		CourseRegistration cR= registrationService.findCourseRegistrations(998,5555);
		Assertions.assertEquals(5555, cR.getStudent().getId());
		Assertions.assertEquals(998, cR.getCourse().getCourseid());
	}
	
	
	@Test
	@Transactional
	void testSaveRegistration() {
		CourseRegistration R =new CourseRegistration();
		R.setCourse(courseService.find(997));
		R.setStudent(studentService.find(5555));
		R.setPgrade(0);
		R.setFgrade(0);
		R.setAvgrade(0);
		registrationService.save(R);
		CourseRegistration stored=registrationService.findCourseRegistrations(997,5555);
		Assertions.assertEquals(5555,stored.getStudent().getId());
		Assertions.assertEquals(997,stored.getCourse().getCourseid());
		
	}
	
	
	@Test
	@Transactional
	void testUpdateRegistration() {
		CourseRegistration R =new CourseRegistration();
		R.setCourse(courseService.find(997));
		R.setStudent(studentService.find(5555));
		R.setPgrade(0);
		R.setFgrade(0);
		R.setAvgrade(0);
		registrationService.save(R);
		R.setAvgrade(50);
		R.setPgrade(55);
	    R.setFgrade(45);
		registrationService.update(R);
		CourseRegistration stored=registrationService.findCourseRegistrations(997,5555);
		Assertions.assertEquals(50,stored.getAvgrade());
		Assertions.assertEquals(55,stored.getPgrade());
		Assertions.assertEquals(45,stored.getFgrade());
	}


	
	@AfterAll
	@Transactional
	public void cleanUp(){
		List<Courses> listC= courseService.findCourseByInstructor("gmarios");
		List<StudentRegistration> listS = studentService.findAll();
		List<CourseRegistration> listCR = registrationService.findRegistrationByCourseid(998);
		for(CourseRegistration CR :listCR)registrationService.delete(CR);
		for(Courses c :listC)courseService.delete(c.getCourseid());
		for(StudentRegistration s :listS)studentService.delete(s.getId());
		
	}
}
