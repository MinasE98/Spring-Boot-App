package com.WebApp;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;

import com.WebApp.controller.CoursesMgtAppController;



@SpringBootTest
@TestPropertySource(
  locations = "classpath:application-dev.properties")
@AutoConfigureMockMvc
class TestWebAppController {
	
	@Autowired
    private WebApplicationContext context;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	CoursesMgtAppController appController;

	@BeforeEach
    public void setup() {
		mockMvc = MockMvcBuilders
          .webAppContextSetup(context)
          .build();
    }
	@Test
	@Order(1)
	void testControllerIsNotNull() {
		Assertions.assertNotNull(appController);
	}
	
	@Test
	@Order(2)
	void testMockMvcIsNotNull() {
		Assertions.assertNotNull(mockMvc);
	}
	
	

	
	@WithMockUser(value = "gmarios")
	@Test 
	@Order(3)
	void testSaveCoursesReturnsPage() throws Exception {	    
	    MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
	    multiValueMap.add("courseid", "289");
	    multiValueMap.add("name","Texnologia");
	    multiValueMap.add("instructor", "gmarios");
	    multiValueMap.add("description", null);
	    
		mockMvc.perform(
				post("/courses/save")
			    .params(multiValueMap))
				.andExpect(status().isFound())
				.andExpect(view().name("redirect:/courses/list"));
	}
	@WithMockUser(value = "gmarios")
	@Test 
	@Order(4)
	void testCoursesListReturnsPage() throws Exception {
		mockMvc.perform(get("/courses/list")).
		andExpect(status().isOk()).
		andExpect(view().name("Courses/CoursesList"));		
	}
	@WithMockUser(value = "gmarios")
	@Test 
	@Order(5)
	@DisplayName("Add student to the system")
	void testAddStudent() throws Exception {
	    	    
	    MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
	    multiValueMap.add("id", Integer.toString(6969));
	    multiValueMap.add("name","Markos Xatzikostas");
	    multiValueMap.add("semester", Integer.toString(8));
	    multiValueMap.add("yor", Integer.toString(2019));
	    
		mockMvc.perform(
				post("/students/save")
			    .params(multiValueMap))
				.andExpect(status().isFound())
				.andExpect(view().name("redirect:/students/list"));
	}
	
	@WithMockUser(value = "gmarios")
	@Test 
	@Order(6)
	@DisplayName("Show Students To Be Added To Course")
	void testShowStudentsToBeAddedToCourse() throws Exception {
	    MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
	    multiValueMap.add("name", "Texnologia");
	    multiValueMap.add("courseid", Integer.toString(289));
	    
		mockMvc.perform(
				post("/courses/add_student")
			    .params(multiValueMap))
				.andExpect(status().isOk())
				.andExpect(view().name("Courses/addform"));
	}
	@WithMockUser(value = "gmarios")
	@Test 
	@Order(7)
	@DisplayName("Add Students To Course")
	void testAddStudentsToCourse() throws Exception {
	    MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
	    multiValueMap.add("studentid", Integer.toString(6969));
	    multiValueMap.add("courseid", Integer.toString(289));
	    
		mockMvc.perform(
				post("/courses/add_student_in_course")
			    .params(multiValueMap))
				.andExpect(status().isFound())
				.andExpect(view().name("redirect:/courses/add_student?courseid=289"));
	}
	@WithMockUser(value = "gmarios")
	@Test 
	@Order(8)
	@DisplayName("Add Student grade For Course")
	void testAddStudentGradeForCourse() throws Exception {
	    MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
	    multiValueMap.add("studentid", Integer.toString(6969));
	    multiValueMap.add("courseid", Integer.toString(289));
	    
	    
		mockMvc.perform(
				post("/courses/add_student_grade")
			    .params(multiValueMap))
				.andExpect(status().isOk())
				.andExpect(view().name("Courses/gradesForm"));
	}
	
	@WithMockUser(value = "gmarios")
	@Test
	@Order(9)
	@DisplayName("Remove Students From Course")
	void testRemoveStudentsFromCourse() throws Exception {
	    MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
	    multiValueMap.add("studentid", Integer.toString(6969));
	    multiValueMap.add("courseid", Integer.toString(289));
	    
		mockMvc.perform(
				post("/courses/rem_student")
			    .params(multiValueMap))
				.andExpect(status().isFound())
				.andExpect(view().name("redirect:/courses/show_students?courseid=289"));
	}
	

	

}
