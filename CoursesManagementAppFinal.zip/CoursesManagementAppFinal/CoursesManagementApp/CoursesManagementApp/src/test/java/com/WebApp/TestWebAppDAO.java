package com.WebApp;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import com.WebApp.DAO.CourseRegistrationDAO;
import com.WebApp.DAO.CoursesDAO;
import com.WebApp.DAO.StudentRegistrationDAO;
import com.WebApp.model.CourseRegistration;
import com.WebApp.model.Courses;
import com.WebApp.model.StudentRegistration;
@SpringBootTest
@TestPropertySource( locations = "classpath:application-dev.properties")
@TestInstance(Lifecycle.PER_CLASS)
class TestWebAppDAO {
	@Autowired
	CoursesDAO coursesDAO;
	
	@Autowired
	StudentRegistrationDAO studentDAO;
	
	@Autowired
	CourseRegistrationDAO registrationsDAO;
	
	
	@BeforeAll
    public void setup() {
		StudentRegistration tS= new StudentRegistration();
		tS.setId(4249);
		tS.setName("Kostis Pirkotis");
		tS.setSemester(7);
		tS.setYor(2018);
		studentDAO.save(tS);
		Courses tC = new Courses();
		tC.setCourseid(204);
		tC.setInstructor("kostas");
		tC.setName("Testing1");
		tC.setDescription(null);
		coursesDAO.save(tC);
		CourseRegistration R1 =new CourseRegistration();
		R1.setCourse(tC);
		R1.setStudent(tS);
		R1.setPgrade(65);
		R1.setFgrade(55);
		R1.setAvgrade(60);
		registrationsDAO.save(R1);
		
    }
	
	
	@Test
	void testCoursesDAOIsNotNull() {
		Assertions.assertNotNull(coursesDAO);
	}
	
	
	@Test
	void testfindCourseByInstructor() {
		List<Courses> storedCourses = coursesDAO.findCourseByInstructor("gmarios");
		Assertions.assertNotNull(storedCourses);
		for (Courses sR : storedCourses)Assertions.assertEquals("gmarios", sR.getInstructor());
		
	}
	
	
	@Test
	void testCourseRegistrationDAOIsNotNull() {
		Assertions.assertNotNull(registrationsDAO);
	}
	

	@Test
	void testfindCourseRegistrationsShouldReturnOneRegistration() {
		CourseRegistration cR= registrationsDAO.findCourseRegistrations(204,4249);
		Assertions.assertEquals(204, cR.getCourse().getCourseid());
		Assertions.assertEquals(4249, cR.getStudent().getId());
	}
	
	
	@Test
	void testfindRegistrationByCourseidShouldReturnAList() {
		List<CourseRegistration> listcR= registrationsDAO.findRegistrationByCourseid(204);
		Assertions.assertNotNull(listcR);
		for (CourseRegistration cR : listcR)Assertions.assertEquals(204, cR.getCourse().getCourseid());
	}
	
	
	@Test
	void testfindRegistrationByCourseidShouldBeWrong() {
		List<CourseRegistration> listcR= registrationsDAO.findRegistrationByCourseid(202);
		Assertions.assertNotNull(listcR);
		for (CourseRegistration cR : listcR)Assertions.assertNotEquals(204, cR.getCourse().getCourseid());
	}
	
	
	@Test
	void testfindRegistrationByStudentidShouldReturnAList() {
		List<CourseRegistration> listcR= registrationsDAO.findRegistrationByStudentid(4249);
		Assertions.assertNotNull(listcR);
		for (CourseRegistration cR : listcR)Assertions.assertEquals(4249, cR.getStudent().getId());
	}
	
	
	@AfterAll
	@Transactional
	public void cleanUp(){
		List<Courses> listC= coursesDAO.findCourseByInstructor("kostas");
		List<StudentRegistration> listS = studentDAO.findAll();
		List<CourseRegistration> listCR = registrationsDAO.findRegistrationByCourseid(204);
		for(CourseRegistration CR :listCR)registrationsDAO.delete(CR);
		for(Courses c :listC)coursesDAO.deleteById(c.getCourseid());
		for(StudentRegistration s :listS)studentDAO.deleteById(s.getId());
		
	}
	
}
